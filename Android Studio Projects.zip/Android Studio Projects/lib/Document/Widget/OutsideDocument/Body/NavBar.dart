import 'package:flutter/material.dart';

class NaviButton extends StatelessWidget {
  final VoidCallback onTap; // Function to run when button is pressed
  final String label;
  final IconData icon;

  const NaviButton({
    super.key,
    required this.onTap,
    this.label = 'Add Document',
    this.icon = Icons.add,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity, // full width button
      height: 50,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 24),
        label: Text(
          label,
          style: const TextStyle(fontSize: 18),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.green,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}
