import 'package:alaga/Document/Widget/OutsideDocument/Body/NavBar.dart';
import 'package:flutter/material.dart';
import '../../Widget/OutsideDocument/Body/DocumentList.dart';
import '../../Widget/OutsideDocument/Body/FilterButtons.dart';
import '../../Widget/OutsideDocument/Body/MainAppBar.dart';
import '../../Widget/OutsideDocument/Body/SearchBar.dart';
import 'AddDocumentList.dart';


class DocumentScreen extends StatefulWidget {
  const DocumentScreen({super.key});

  @override
  State<DocumentScreen> createState() => _DocumentScreenState();
}

class _DocumentScreenState extends State<DocumentScreen> {
  TextEditingController searchController = TextEditingController();
  List<Map<String, dynamic>> documents = [];

  List<Map<String, dynamic>> get filteredDocuments {
    final query = searchController.text.toLowerCase();
    if (query.isEmpty) return documents;

    return documents.where((doc) {
      return doc['title'].toLowerCase().contains(query) ||
          doc['facility'].toLowerCase().contains(query) ||
          doc['meta'].toLowerCase().contains(query);
    }).toList();
  }

  void addDocument(Map<String, dynamic> newDoc) {
    setState(() {
      documents.add(newDoc);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: DocumentAppBar(addDocument: addDocument),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            const SizedBox(height: 10),
            DocumentSearchBar(
              controller: searchController,
              onChanged: (_) => setState(() {}), // keeps filtering working
            ),

            const SizedBox(height: 5),

            FilterButtons(
              documents: documents, // the full list
              onFiltered: (filteredList) {
                setState(() {
                  documents = filteredList; // update the list shown
                });
              },
            ),

            const SizedBox(height: 10),

            Expanded(
              child: DocumentList(documents: filteredDocuments),
            ),

            const SizedBox(height: 10),
            NaviButton(
              onTap: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AddDocumentScreen(),
                  ),
                );

                if (result != null) {
                  addDocument(result); // update your list
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
